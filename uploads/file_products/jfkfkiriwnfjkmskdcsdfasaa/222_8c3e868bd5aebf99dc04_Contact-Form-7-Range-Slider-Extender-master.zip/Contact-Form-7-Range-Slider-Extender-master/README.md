# Contact Form-7 Range Slider Extender
<p align="center">This simple plugin adds new features to existing range slider available in Contact Form 7 plugin</p>
</br>
# Changelog:
</br>
<p>0.1 - Displays current value</p>
<p align="center">
  <img src="https://media.giphy.com/media/3o7buc0vGfOU76JwXu/giphy.gif" width="350"/>
</p>
